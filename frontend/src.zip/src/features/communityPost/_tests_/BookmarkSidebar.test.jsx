import { render, screen } from "@testing-library/react";
import BookmarkSidebar from "../components/BookmarkSidebar";

describe("BookmarkSidebar Component", () => {
  test("renders bookmarked posts", () => {
    const bookmarks = [{ id: 1, title: "Saved Post" }];
    
    render(<BookmarkSidebar bookmarks={bookmarks} />);
    
    expect(screen.getByText("Saved Post")).toBeInTheDocument();
  });

  test("shows empty state", () => {
    render(<BookmarkSidebar bookmarks={[]} />);
    
    expect(screen.getByText(/no bookmarks/i)).toBeInTheDocument();
  });
});