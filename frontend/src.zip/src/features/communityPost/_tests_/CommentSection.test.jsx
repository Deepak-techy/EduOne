import { render, screen, fireEvent } from "@testing-library/react";
import CommentSection from "../components/CommentSection";

describe("CommentSection Component", () => {
  test("renders comments", () => {
    const comments = [{ id: 1, text: "Nice post!" }];
    
    render(<CommentSection comments={comments} />);
    
    expect(screen.getByText("Nice post!")).toBeInTheDocument();
  });

  test("adds new comment", () => {
    const mockAdd = jest.fn();
    render(<CommentSection comments={[]} onAddComment={mockAdd} />);
    
    const input = screen.getByPlaceholderText(/write comment/i);
    fireEvent.change(input, { target: { value: "Hello" } });

    fireEvent.click(screen.getByText(/add/i));

    expect(mockAdd).toHaveBeenCalled();
  });
});