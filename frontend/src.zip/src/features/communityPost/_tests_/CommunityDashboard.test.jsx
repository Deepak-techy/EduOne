import { render, screen } from "@testing-library/react";
import CommunityDashboard from "../pages/CommunityDashboard";

describe("CommunityDashboard", () => {
  test("renders dashboard", () => {
    render(<CommunityDashboard />);
    
    expect(screen.getByText(/community/i)).toBeInTheDocument();
  });
});