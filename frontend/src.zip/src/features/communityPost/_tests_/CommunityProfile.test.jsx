import { render, screen } from "@testing-library/react";
import CommunityProfile from "../pages/CommunityProfile";

describe("CommunityProfile", () => {
  test("renders profile info", () => {
    render(<CommunityProfile />);
    
    expect(screen.getByText(/profile/i)).toBeInTheDocument();
  });
});