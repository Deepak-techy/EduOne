import { render, screen, fireEvent } from "@testing-library/react";
import CreatePostModal from "../components/CreatePostModal";

describe("CreatePostModal Component", () => {
  test("renders modal when open", () => {
    render(<CreatePostModal isOpen={true} />);
    
    expect(screen.getByText(/create post/i)).toBeInTheDocument();
  });

  test("input updates on typing", () => {
    render(<CreatePostModal isOpen={true} />);
    
    const input = screen.getByPlaceholderText(/title/i);
    fireEvent.change(input, { target: { value: "New Post" } });

    expect(input.value).toBe("New Post");
  });

  test("submit button works", () => {
    const mockSubmit = jest.fn();
    render(<CreatePostModal isOpen={true} onSubmit={mockSubmit} />);
    
    fireEvent.click(screen.getByText(/submit/i));
    
    expect(mockSubmit).toHaveBeenCalled();
  });
});