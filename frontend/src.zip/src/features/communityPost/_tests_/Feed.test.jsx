import { render, screen } from "@testing-library/react";
import Feed from "../components/Feed";

const mockPosts = [
  { id: 1, title: "Post 1" },
  { id: 2, title: "Post 2" },
];

describe("Feed Component", () => {
  test("renders list of posts", () => {
    render(<Feed posts={mockPosts} />);
    
    expect(screen.getByText("Post 1")).toBeInTheDocument();
    expect(screen.getByText("Post 2")).toBeInTheDocument();
  });

  test("renders empty state when no posts", () => {
    render(<Feed posts={[]} />);
    
    expect(screen.getByText(/no posts/i)).toBeInTheDocument();
  });
});