import { render, screen, fireEvent } from "@testing-library/react";
import Filters from "../components/Filters";

describe("Filters Component", () => {
  test("renders filter buttons", () => {
    render(<Filters />);
    
    expect(screen.getByText(/all/i)).toBeInTheDocument();
    expect(screen.getByText(/students/i)).toBeInTheDocument();
    expect(screen.getByText(/teachers/i)).toBeInTheDocument();
  });

  test("clicking filter triggers change", () => {
    const mockFn = jest.fn();
    render(<Filters onChange={mockFn} />);
    
    fireEvent.click(screen.getByText(/students/i));
    
    expect(mockFn).toHaveBeenCalled();
  });
});