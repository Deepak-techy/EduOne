import { render, screen, fireEvent } from "@testing-library/react";
import PostCard from "../components/PostCard";

const mockPost = {
  id: 1,
  title: "Test Post",
  content: "Test content",
  likes: 0,
  dislikes: 0,
  bookmarked: false,
};

describe("PostCard Component", () => {
  test("renders post title and content", () => {
    render(<PostCard post={mockPost} />);
    
    expect(screen.getByText("Test Post")).toBeInTheDocument();
    expect(screen.getByText("Test content")).toBeInTheDocument();
  });

  test("like button increments likes", () => {
    render(<PostCard post={mockPost} />);
    
    const likeBtn = screen.getByText(/like/i);
    fireEvent.click(likeBtn);

    // depends on your UI (update if needed)
    expect(screen.getByText("1")).toBeInTheDocument();
  });

  test("bookmark toggle works", () => {
    render(<PostCard post={mockPost} />);
    
    const bookmarkBtn = screen.getByRole("button", { name: /bookmark/i });
    fireEvent.click(bookmarkBtn);

    expect(bookmarkBtn).toBeInTheDocument();
  });
});